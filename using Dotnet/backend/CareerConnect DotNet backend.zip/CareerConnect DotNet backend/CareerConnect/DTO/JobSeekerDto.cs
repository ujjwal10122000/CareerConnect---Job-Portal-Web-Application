﻿namespace CareerConnect.DTO
{
    public class JobSeekerDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Description { get; set; }
        public string? Projects { get; set; }
        public string Skills { get; set; }
        public string? Resume { get; set; }
    }
}
