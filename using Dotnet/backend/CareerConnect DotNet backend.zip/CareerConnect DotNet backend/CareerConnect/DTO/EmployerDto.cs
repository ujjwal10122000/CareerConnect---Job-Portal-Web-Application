﻿namespace CareerConnect.DTO
{
    public class EmployerDto
    {
        public string CompanyName { get; set; }
        public string CompanyDescription { get; set; }
    }
}
