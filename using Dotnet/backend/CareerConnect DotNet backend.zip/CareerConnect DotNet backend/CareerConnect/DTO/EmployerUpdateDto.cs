﻿namespace CareerConnect.DTO
{
    public class EmployerUpdateDto
    {
        public string CompanyName { get; set; }
        public string CompanyDescription { get; set; }
    }
}
